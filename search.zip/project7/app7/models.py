from django.db import models
from django.contrib.auth.models import AbstractUser



#Create your models here.
class CustomUser(AbstractUser):
    email=models.EmailField()
    phone=models.CharField(max_length=10)


class employee(models.Model):
    Emp_id=models.IntegerField()
    Emp_name=models.CharField(max_length=50)
    place=models.CharField(max_length=200)
    company_name=models.CharField(max_length=200)
    salary=models.IntegerField()


class Book(models.Model):
    title=models.CharField(max_length=100)
    author=models.CharField(max_length=100)
    pdf=models.FileField(upload_to='book/pdf')
    cover=models.ImageField(upload_to='book/cover',null=True,blank=True)